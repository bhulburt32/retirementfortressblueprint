# v185 update (rolls up v179–v185)

Copy `src/fortress-mapper.html`, `docs/` and `assets/edu-slides/` over the repo's, or apply `v185-since-v172.patch`
(cumulative from the v172 the repo holds). Bump `package.json` to 1.185.0 and add
`'t-slideorder', 't-wealthperf', 't-sso6', 't-benchrisk', 't-payroll', 't-sqpies', 't-loadtop'` to `SUITE`.

- **v185** — a **Load case** button in the header beside Start new case; it opens the same file picker as
  Upload case file in section 23 (.json/.txt case files, or a household .docx). `#loadCaseTop`. Test `t-loadtop.js`
  (loads `samples/default-case-smith.json` — point it at the repo's path if it differs).
- **v184** — two donut charts under the status-quo tiles in section 06: qualified vs. non-qualified and at risk vs.
  not at risk (`accountSplits`, `pieCard`, `renderSqPies`, `AT_RISK_POS`). Test `t-sqpies.js`.
- Earlier in this drop: v179 slide order · v180 Wealth Report performance analysis · v181 six Social Security
  scenarios, benchmark risk, RMD educational slides · v182 payroll taxes · v183 slide 6 tile, Foundation incl. buffer.
