# v195 update — administrators see every case

Copy `src/fortress-mapper.html`, `src/standalone-head.html` (favicon), `docs/` and `assets/edu-slides/` over the
repo's, and `api/src/shared.js` + `api/src/functions/cases.js` over the repo's `api/src/` (the connection-string
and `guard()` changes from PR #7 are included, plus the export change below). Or apply `v195-since-v172.patch`
for the page and guide. Bump `package.json` to 1.195.0.

- The Saved cases panel now asks the server for every case the signed-in advisor may see (`GET /api/cases?all=1`).
  The server returns everything to an administrator (`OWNER_IDS`) and only the caller's own to anyone else, so
  nothing changes for advisors; administrators get every advisor's cases with the saver's name on each row and a
  **Show** control (every case I can see / my cases only). Open works on any of them; a save is always recorded
  under the signed-in advisor. Export all follows the same rule (`/api/cases/export?all=1`; the API's export
  route now honours `all=1` for administrators).
- This version also carries the changes published to the artifact by another session today — the fortress mark
  in the masthead beside the title, the Walls income start / growth-before-income / tax-free Walls assumptions in
  section 03, the wider account table, the gold panel titles on output graphics, and the removal of the Road to
  Retirement Fortress video button. The header Load case button is gone, as intended; Upload case file in section 23 is the way to open a case file.
- Tests: `t-azure.js` with `stub-api.js` (the stub now returns `advisorId` on list rows) covers the panel.

Earlier in this drop (v179–v185): slide order, Wealth Report performance analysis, six Social Security scenarios,
benchmark risk, RMD educational slides, payroll taxes, slide 6 tile, Foundation incl. buffer, asset donuts,
favicon.
