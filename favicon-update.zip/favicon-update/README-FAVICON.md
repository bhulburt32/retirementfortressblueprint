# Favicon for the Azure site

`src/standalone-head.html` now carries the Retirement Fortress mark as the page icon — the SVG for modern
browsers, a .ico fallback, a 180 px apple-touch-icon and the navy theme colour — all embedded as data URIs, so
the build needs no extra files and nothing else changes. `assets/logo/` holds the logo set for reference.

Copy `src/standalone-head.html` over the repo's and add `assets/logo/`. `npm run build:azure` picks the head up
automatically; after the deploy, a hard refresh (Ctrl/Cmd-Shift-R) on www.retirementfortressblueprint.com
shows the fortress in the tab. Browsers cache favicons aggressively, so an old tab may need closing and reopening.
