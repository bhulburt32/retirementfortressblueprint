# API fix: Cosmos via connection string, readable 500s

Static Web Apps managed functions have no managed identity, so `DefaultAzureCredential` cannot reach Cosmos DB and
every `/api/cases` call died with an empty HTTP 500. This drop:

- `api/src/shared.js` — uses `COSMOS_CONNECTION_STRING` when set (falls back to `COSMOS_ENDPOINT` + Entra credential
  for a bring-your-own Functions app or local `az login`); adds `guard()`, which turns an exception into a 500 whose
  body is a one-line reason ("Database: …") and logs the stack.
- `api/src/functions/cases.js`, `summary.js` — every handler wrapped in `guard()`.
- `README-AZURE.md` — the settings table and the identity note updated.

Copy `api/src/` over the repo's and replace `README-AZURE.md`. No page change.
